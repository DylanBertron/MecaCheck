# MecaCheck V20

V20 ajoute une vraie interface de connexion au backend IA, un test /health, l’envoi des mesures et un historique local de conversation.

## Frontend
Le frontend peut rester sur GitHub Pages. Dans Assistant IA > Connexion IA, saisir l’URL publique du backend.

## Backend
Dans `server/`, définir `OPENAI_API_KEY` dans les variables secrètes de l’hébergeur. Ne jamais mettre cette clé dans `index.html`, GitHub Pages ou l’application mobile.

Routes : `GET /health` et `POST /api/diagnose`.
