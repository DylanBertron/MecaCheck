import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'MecaCheck AI', aiConfigured: !!client }));

app.post('/api/diagnose', async (req, res) => {
  const { vehicle = {}, symptoms = '', dtcs = [], measurements = [], history = [] } = req.body || {};
  if (!symptoms && !dtcs.length && !measurements.length) {
    return res.status(400).json({ error: 'Décris au moins un symptôme, un DTC ou une mesure.' });
  }
  if (!client) {
    return res.status(503).json({ error: 'IA non configurée sur le serveur.' });
  }

  const system = `Tu es MecaCheck AI, assistant de diagnostic automobile pour techniciens.\n\nRègles :\n- Raisonne à partir des données fournies et signale clairement ce qui manque.\n- Ne condamne jamais une pièce uniquement sur un DTC.\n- Distingue hypothèse, contrôle à effectuer et conclusion.\n- Propose un ordre de contrôle pratique et sûr.\n- N'invente pas une valeur constructeur. Si une spécification est nécessaire, dis de consulter la documentation constructeur.\n- Réponds en français.\n- Format : Résumé, Hypothèses classées sans score arbitraire, Contrôles prioritaires, Mesures à relever, Ce qui confirmerait/infirmerait chaque hypothèse, Prochaine action.`;

  const payload = JSON.stringify({ vehicle, symptoms, dtcs, measurements, history });
  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.6-mini',
      input: [
        { role: 'system', content: [{ type: 'input_text', text: system }] },
        { role: 'user', content: [{ type: 'input_text', text: `Dossier MecaCheck:\n${payload}` }] }
      ]
    });
    res.json({ ok: true, answer: response.output_text || 'Aucune réponse.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur du moteur IA.' });
  }
});

app.listen(port, () => console.log(`MecaCheck AI server listening on ${port}`));
