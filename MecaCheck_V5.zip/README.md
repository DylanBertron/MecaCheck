# MecaCheck V5
Prototype mobile de diagnostic automobile.

## Sources ouvertes utilisées
- OBDex: DTC génériques et PIDs via JSON distant; le dépôt annonce des données CC0 et des endpoints sans clé.
- NHTSA vPIC: décodage VIN public; respecter la politique d'usage et éviter les recherches en masse.

La V5 n'intègre pas de SIV français, de données OEM propriétaires ni de schémas OEM.
